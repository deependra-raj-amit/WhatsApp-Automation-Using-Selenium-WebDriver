from selenium import webdriver  
from urllib.parse import quote


with open('message.txt', 'r') as  file:
    msg = file.read()

msg = (quote(msg))

numbers = []
with open('numbers.txt', 'r') as file:
    for num in file.readlines():
        numbers.append(num.rstrip())

